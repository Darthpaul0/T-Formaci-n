/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.wumpasmachine;

/**
 *
 * @author pferna12
 */
public class Wumpas {
    private float price;

    public Wumpas() {
        this.price = 1F;
    }

    public float getPrice() {
        return price;
    }
}
